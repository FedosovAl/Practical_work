# TODO здесь писать код

numbers = [[element for element in range(number, 13, 4)]
           for number in range(1, 5)]
print(numbers)

