# TODO здесь писать код

text = input('Введите строку: ').title()
print('Результат:', text)
