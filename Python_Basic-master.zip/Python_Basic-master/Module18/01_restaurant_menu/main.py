# TODO здесь писать код

available_menu = input('Доступное меню: ')
menu = available_menu.split(';')
print('На данный момент в меню есть:', ', '.join(menu))
